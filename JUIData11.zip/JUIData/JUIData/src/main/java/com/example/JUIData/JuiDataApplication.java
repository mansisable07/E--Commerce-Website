package com.example.JUIData;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JuiDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(JuiDataApplication.class, args);
	}

}
