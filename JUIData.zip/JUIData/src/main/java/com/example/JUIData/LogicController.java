package com.example.JUIData;

import java.util.List;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;

@RestController
public class LogicController {

	
	@Autowired
	DatabaseRepository dr;
	
	@GetMapping("")
	public ModelAndView lp()
	{
		ModelAndView mv =new ModelAndView();
		mv.setViewName("index");
		return mv;
	}
	
	@PostMapping("registration")
	public ModelAndView newRegistration(@RequestParam(name="t1")String name,
			                             @RequestParam(name="t2")long mb,
			                             @RequestParam(name="t3")String email,
			                             @RequestParam(name="t4")String pass)
	{
		
		Customer c1=new Customer();
		c1.setName(name);
		c1.setEmail(email);
		c1.setPasskey(pass);
		c1.setContact(mb);
		
		dr.save(c1);
		
		
		ModelAndView mv =new ModelAndView();
		mv.setViewName("index");
		mv.addObject("data","New Record Created Successfully");
		return mv;
	} 
	
	
	@PostMapping("login")
	public ModelAndView login(@RequestParam(name="t1")String user,
			                  @RequestParam(name="t2")String pass)
	{
		 List<Customer> c1=dr.findAll();
		 for(Customer cust:c1)
		 {
			 if((cust.getEmail().equals(user))&&(cust.getPasskey().equals(pass)))
			 {
                 				ModelAndView mv=new ModelAndView();
                 				mv.addObject("id", cust.getId());
                 				mv.addObject("name", cust.getName());
                 				mv.addObject("contact", cust.getContact());
                 				mv.addObject("email", cust.getEmail());
                 				mv.setViewName("welcome");
                 				return mv;
			 }
		 }
		 ModelAndView mv=new ModelAndView();
		 mv.addObject("data","user id or password mismatched");
		 mv.setViewName("index");
			return mv;
	}
	
	
	
	@PostMapping("second")
	public ModelAndView getSecondPage(@RequestParam(name="t1")String cname,
			                          @RequestParam(name="t2")String email,
			                          @RequestParam(name="t3")long contact,
			                          @RequestParam(name="t4")int price,
			                          @RequestParam(name="t5")String pname
			) 
			throws RazorpayException
	{
		
		RazorpayClient razorpay = new RazorpayClient("key", "secretkey");

		JSONObject orderRequest = new JSONObject();
		orderRequest.put("amount",(price*100));
		orderRequest.put("currency","INR");
		orderRequest.put("receipt", pname+cname);
		JSONObject notes = new JSONObject();
		notes.put("notes_key_1",cname);
		notes.put("notes_key_2",pname);
		orderRequest.put("notes",notes);

		Order order = razorpay.orders.create(orderRequest);
		
		
		
		ModelAndView mv =new ModelAndView();
		mv.setViewName("welcome2");
		mv.addObject("id",order.get("id"));
		mv.addObject("amount",order.get("amount"));
		mv.addObject("name",cname);
		mv.addObject("email",email);
		mv.addObject("contact",contact);
		
		return mv;
	}

	
}

